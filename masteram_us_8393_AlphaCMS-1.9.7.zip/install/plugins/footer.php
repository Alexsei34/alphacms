<div class='foot'><a href='https://alpha-cms.ru'>AlphaCMS 2019-<?=date('Y')?></a></div>

</body>