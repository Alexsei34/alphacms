<div class='panel-top-optimize'>
  
<?php require (ROOT.'/style/version/'.version('DIR').'/includes/panel-top-nav.php'); ?> 
  
</div>
  
<div class='panel-top-optimize2'></div>