<?php

define('PARAM_ICONS_MINI_COLOR', 'white');
define('PARAM_ICONS_MINI_BACKGROUND', '#53a5e0');