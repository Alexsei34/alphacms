<div class='name_community'>
<?=communities::name($comm['ID'])?>
<div><?=tabs($comm['MESSAGE'])?></div>
</div>