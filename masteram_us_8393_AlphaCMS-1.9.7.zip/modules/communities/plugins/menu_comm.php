<div class='menu_user_optimize'>
<div class='menu_user_container bbs_op'>  
<?=direct::components(ROOT.'/modules/communities/components/menu_comm/')?>
</div>
<a class='menu_user_for_left' ajax='no' id='bbs_for' data-factor='-1'><?=icons('angle-left', 30)?></a>
<a class='menu_user_for_right' ajax='no' id='bbs_for' data-factor='1'><?=icons('angle-right', 30)?></a>
</div>