<div class='search-main-optimize'>
<form method='post' class='ajax-form2' action='/m/search/?type=videos'>
<input type='text' name='search' class='search-main' placeholder='<?=lg('Поиск по видеофайлам')?>'> 
<button class="search-main-button ajax-button-search"><?=icons('search', 20)?></button>
</form>
</div>