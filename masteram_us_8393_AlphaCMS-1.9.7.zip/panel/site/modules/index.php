<div class='list-body'>
<div class='list-menu'><?=lg('Вы можете отключить некоторые модули - они больше не будут отображаться на сайте')?>:</div>
<?=direct::components(ROOT.'/panel/site/modules/access/', 0)?>
</div>