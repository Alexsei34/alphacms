<?php
  
header('location: /');